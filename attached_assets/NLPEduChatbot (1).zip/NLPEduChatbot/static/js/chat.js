document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const generalChatForm = document.getElementById('general-chat-form');
    const generalInput = document.getElementById('general-input');
    const generalMessages = document.getElementById('general-messages');
    const suggestionChips = document.querySelectorAll('.suggestion-chip');
    
    const codeChatForm = document.getElementById('code-chat-form');
    const codeInput = document.getElementById('code-input');
    const codeMessages = document.getElementById('code-messages');
    const codeSamples = document.querySelectorAll('.code-sample');
    
    const compareChatForm = document.getElementById('compare-chat-form');
    const compareCodeInput = document.getElementById('compare-code-input');
    const sourceLibrary = document.getElementById('source-library');
    const targetLibrary = document.getElementById('target-library');
    const performanceComparisonToggle = document.getElementById('performance-comparison');
    const compareMessages = document.getElementById('compare-messages');
    
    const chatHistory = document.getElementById('chat-history');
    
    // Handle general NLP questions
    generalChatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const query = generalInput.value.trim();
        if (!query) return;
        
        // Add user message to chat
        addMessage(generalMessages, query, 'user');
        generalInput.value = '';
        
        // Show typing indicator
        const typingIndicator = addTypingIndicator(generalMessages);
        
        // Send request to backend
        fetch('/chat/ask', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query })
        })
        .then(response => response.json())
        .then(data => {
            // Remove typing indicator
            removeTypingIndicator(typingIndicator);
            
            // Add bot response
            if (data.error) {
                addErrorMessage(generalMessages, data.error);
            } else {
                addMessage(generalMessages, data.response, 'bot');
                
                // Add to chat history
                addToHistory(query);
            }
        })
        .catch(error => {
            removeTypingIndicator(typingIndicator);
            addErrorMessage(generalMessages, 'Error sending message: ' + error.message);
        });
    });
    
    // Handle code explanation
    codeChatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const code = codeInput.value.trim();
        if (!code) return;
        
        // Add user message to chat
        addMessage(codeMessages, 'Explain this code:\n\n```python\n' + code + '\n```', 'user');
        
        // Show typing indicator
        const typingIndicator = addTypingIndicator(codeMessages);
        
        // Send request to backend
        fetch('/chat/explain-code', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ code })
        })
        .then(response => response.json())
        .then(data => {
            // Remove typing indicator
            removeTypingIndicator(typingIndicator);
            
            // Add bot response
            if (data.error) {
                addErrorMessage(codeMessages, data.error);
            } else {
                addMessage(codeMessages, data.explanation, 'bot');
                
                // Add to chat history
                addToHistory('Code explanation');
            }
        })
        .catch(error => {
            removeTypingIndicator(typingIndicator);
            addErrorMessage(codeMessages, 'Error analyzing code: ' + error.message);
        });
    });
    
    // Handle library comparison
    compareChatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const code = compareCodeInput.value.trim();
        const source = sourceLibrary.value;
        const target = targetLibrary.value;
        
        if (!code) return;
        if (source === target) {
            addErrorMessage(compareMessages, 'Source and target libraries must be different');
            return;
        }
        
        // Add user message to chat
        addMessage(compareMessages, `Convert from ${source} to ${target}:\n\n```python\n${code}\n````, 'user');
        
        // Show typing indicator
        const typingIndicator = addTypingIndicator(compareMessages);
        
        // Send request to backend
        fetch('/chat/compare-code', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                code,
                source_library: source,
                target_library: target
            })
        })
        .then(response => response.json())
        .then(data => {
            // Remove typing indicator
            removeTypingIndicator(typingIndicator);
            
            // Add bot response
            if (data.error) {
                addErrorMessage(compareMessages, data.error);
            } else {
                addMessage(compareMessages, data.comparison, 'bot');
                
                // Add to chat history
                addToHistory(`${source} to ${target} comparison`);
            }
        })
        .catch(error => {
            removeTypingIndicator(typingIndicator);
            addErrorMessage(compareMessages, 'Error comparing code: ' + error.message);
        });
    });
    
    // Helper functions
    function addMessage(container, text, type) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', type + '-message');
        
        const contentDiv = document.createElement('div');
        contentDiv.classList.add('message-content');
        
        // Process markdown-like formatting
        text = processMarkdown(text);
        
        contentDiv.innerHTML = text;
        messageDiv.appendChild(contentDiv);
        
        // Add timestamp
        const timestamp = document.createElement('div');
        timestamp.classList.add('message-timestamp');
        const now = new Date();
        timestamp.textContent = now.toLocaleTimeString();
        messageDiv.appendChild(timestamp);
        
        // Add rating buttons for bot messages
        if (type === 'bot') {
            const ratingContainer = document.createElement('div');
            ratingContainer.classList.add('rating-container');
            
            const likeBtn = document.createElement('button');
            likeBtn.classList.add('rating-btn', 'positive');
            likeBtn.innerHTML = '<i class="bi bi-hand-thumbs-up"></i>';
            likeBtn.title = 'Helpful response';
            
            const dislikeBtn = document.createElement('button');
            dislikeBtn.classList.add('rating-btn', 'negative');
            dislikeBtn.innerHTML = '<i class="bi bi-hand-thumbs-down"></i>';
            dislikeBtn.title = 'Not helpful';
            
            likeBtn.addEventListener('click', function() {
                likeBtn.classList.toggle('active');
                dislikeBtn.classList.remove('active');
                // Send rating to server (can implement later)
            });
            
            dislikeBtn.addEventListener('click', function() {
                dislikeBtn.classList.toggle('active');
                likeBtn.classList.remove('active');
                // Send rating to server (can implement later)
            });
            
            ratingContainer.appendChild(likeBtn);
            ratingContainer.appendChild(dislikeBtn);
            messageDiv.appendChild(ratingContainer);
        }
        
        container.appendChild(messageDiv);
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    }
    
    function addErrorMessage(container, text) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', 'system-message');
        
        const contentDiv = document.createElement('div');
        contentDiv.classList.add('message-content');
        contentDiv.innerHTML = `<p class="text-danger"><i class="bi bi-exclamation-triangle"></i> ${text}</p>`;
        
        messageDiv.appendChild(contentDiv);
        container.appendChild(messageDiv);
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    }
    
    function addTypingIndicator(container) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', 'bot-message', 'typing-indicator');
        
        const contentDiv = document.createElement('div');
        contentDiv.classList.add('message-content');
        contentDiv.innerHTML = `
            <div class="typing-animation">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
        `;
        
        messageDiv.appendChild(contentDiv);
        container.appendChild(messageDiv);
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
        
        return messageDiv;
    }
    
    function removeTypingIndicator(element) {
        if (element && element.parentNode) {
            element.parentNode.removeChild(element);
        }
    }
    
    function addToHistory(query) {
        // Limit query length for display
        const displayQuery = query.length > 30 ? query.substring(0, 30) + '...' : query;
        
        const historyItem = document.createElement('div');
        historyItem.classList.add('history-item');
        historyItem.textContent = displayQuery;
        
        // Add to top of history list
        if (chatHistory.firstChild) {
            chatHistory.insertBefore(historyItem, chatHistory.firstChild);
        } else {
            chatHistory.appendChild(historyItem);
        }
        
        // Limit history items
        if (chatHistory.children.length > 10) {
            chatHistory.removeChild(chatHistory.lastChild);
        }
    }
    
    // Process markdown-like formatting with code highlighting
    function processMarkdown(text) {
        // Replace code blocks ```language ... ``` with styled pre elements
        text = text.replace(/```(\w*)([\s\S]*?)```/g, function(match, language, code) {
            return `<pre class="code-block ${language}"><code>${escapeHtml(code.trim())}</code></pre>`;
        });
        
        // Replace inline code `...` with styled code elements
        text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
        
        // Convert line breaks to <br> tags
        text = text.replace(/\n/g, '<br>');
        
        // Wrap paragraphs
        const paragraphs = text.split('<br><br>');
        return paragraphs.map(p => {
            // Skip wrapping already wrapped elements (code blocks, etc.)
            if (p.includes('<pre') || p.includes('<h')) {
                return p;
            }
            return `<p>${p}</p>`;
        }).join('');
    }
    
    // Helper to escape HTML entities to prevent XSS
    function escapeHtml(text) {
        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
    
    // Suggestion chips click handlers
    if (suggestionChips && suggestionChips.length > 0) {
        suggestionChips.forEach(chip => {
            chip.addEventListener('click', function() {
                const suggestedText = this.getAttribute('data-text');
                if (suggestedText && generalInput) {
                    generalInput.value = suggestedText;
                    generalInput.focus();
                }
            });
        });
    }
    
    // Code samples click handlers
    if (codeSamples && codeSamples.length > 0) {
        const sampleCodeExamples = {
            'nltk-tokenize': `import nltk
from nltk.tokenize import word_tokenize, sent_tokenize

# Sample text for tokenization
text = "Natural language processing (NLP) is a subfield of linguistics, computer science, and artificial intelligence. It's focused on understanding human language."

# Tokenize into sentences
sentences = sent_tokenize(text)
print(f"Sentences: {sentences}")

# Tokenize into words
words = word_tokenize(text)
print(f"Words: {words}")`,

            'spacy-ner': `import spacy

# Load the spaCy English model
nlp = spacy.load("en_core_web_sm")

# Sample text for NER
text = "Apple Inc. is planning to open a new store in New York City next month, according to CEO Tim Cook. The company's headquarters is located in Cupertino, California."

# Process the text with spaCy
doc = nlp(text)

# Extract named entities
entities = [(ent.text, ent.label_) for ent in doc.ents]
print("Named Entities:", entities)`,

            'sklearn-vectorizer': `from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

# Sample documents
documents = [
    "Natural language processing is fascinating.",
    "Machine learning algorithms are powerful.",
    "NLP combines linguistics and machine learning.",
    "Python is great for NLP and machine learning tasks."
]

# Create a bag-of-words representation
count_vectorizer = CountVectorizer()
bow_matrix = count_vectorizer.fit_transform(documents)
print("Feature names:", count_vectorizer.get_feature_names_out())
print("BoW matrix shape:", bow_matrix.shape)

# Create a TF-IDF representation
tfidf_vectorizer = TfidfVectorizer()
tfidf_matrix = tfidf_vectorizer.fit_transform(documents)
print("TF-IDF matrix shape:", tfidf_matrix.shape)`
        };
        
        codeSamples.forEach(sample => {
            sample.addEventListener('click', function() {
                const sampleKey = this.getAttribute('data-sample');
                if (sampleKey && sampleCodeExamples[sampleKey] && codeInput) {
                    codeInput.value = sampleCodeExamples[sampleKey];
                }
            });
        });
    }
    
    // Update performance comparison inclusion
    if (performanceComparisonToggle) {
        performanceComparisonToggle.addEventListener('change', function() {
            // This can be used later to add/remove a parameter to the API call
            console.log("Performance comparison:", this.checked);
        });
    }
    
    // Initialize with sample messages
    // These could be loaded from backend history in future
    // We don't need these since we now have the system messages in the HTML
});