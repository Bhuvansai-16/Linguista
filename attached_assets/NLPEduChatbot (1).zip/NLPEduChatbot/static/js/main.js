// Linguista Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const taskSelect = document.getElementById('task-select');
    const libraryOptions = document.querySelectorAll('input[name="library"]');
    const textInput = document.getElementById('text-input');
    const comparisonContainer = document.getElementById('comparison-container');
    const comparisonText = document.getElementById('comparison-text');
    const processButton = document.getElementById('process-button');
    const showExplanationBtn = document.getElementById('show-explanation');
    const explanationBtnText = document.getElementById('explanation-btn-text');
    const explanationContainer = document.getElementById('explanation-container');
    const resultContainer = document.getElementById('result-container');
    const visualizationContainer = document.getElementById('visualization-container');
    const loadingSpinner = document.getElementById('loading-spinner');
    const errorContainer = document.getElementById('error-container');
    const sampleTextBtn = document.getElementById('sample-text-btn');
    const charCounter = document.getElementById('char-counter');
    
    // State variables
    let currentTask = taskSelect.value;
    let explanationVisible = false;
    
    // Initialize
    updateComparisonVisibility();
    resetDisplay();
    
    // Event listeners
    taskSelect.addEventListener('change', function() {
        currentTask = this.value;
        updateComparisonVisibility();
        resetDisplay();
    });
    
    processButton.addEventListener('click', processText);
    
    showExplanationBtn.addEventListener('click', toggleExplanation);
    
    sampleTextBtn.addEventListener('click', loadSampleText);
    
    textInput.addEventListener('input', function() {
        updateCharCounter(this.value);
    });
    
    // Functions
    function updateComparisonVisibility() {
        if (currentTask === 'text_similarity') {
            comparisonContainer.style.display = 'block';
        } else {
            comparisonContainer.style.display = 'none';
        }
    }
    
    function resetDisplay() {
        resultContainer.style.display = 'none';
        visualizationContainer.style.display = 'none';
        errorContainer.style.display = 'none';
        loadingSpinner.style.display = 'none';
    }
    
    function toggleExplanation() {
        explanationVisible = !explanationVisible;
        
        if (explanationVisible) {
            explanationBtnText.textContent = 'Hide Explanation';
            fetchExplanation(currentTask);
        } else {
            explanationBtnText.textContent = 'Show Explanation';
            explanationContainer.style.display = 'none';
        }
    }
    
    function updateCharCounter(text) {
        charCounter.textContent = text.length + ' characters';
    }
    
    function loadSampleText() {
        // Check if sample_texts.js is loaded and sampleTexts is defined
        if (typeof sampleTexts !== 'undefined') {
            const samples = sampleTexts[currentTask] || sampleTexts.general;
            if (samples && samples.length > 0) {
                // Randomly select a sample text
                const randomIndex = Math.floor(Math.random() * samples.length);
                textInput.value = samples[randomIndex];
                updateCharCounter(textInput.value);
                
                // If it's text similarity, also set comparison text if available
                if (currentTask === 'text_similarity' && sampleTexts.comparison && sampleTexts.comparison.length > 0) {
                    const comparisonIndex = Math.floor(Math.random() * sampleTexts.comparison.length);
                    comparisonText.value = sampleTexts.comparison[comparisonIndex];
                }
            }
        } else {
            console.error('Sample texts not available');
            textInput.value = "Natural language processing (NLP) is a field of artificial intelligence that focuses on the interaction between computers and humans through natural language. The ultimate objective of NLP is to read, decipher, understand, and make sense of human language in a valuable way.";
            updateCharCounter(textInput.value);
        }
    }
    
    function processText() {
        const text = textInput.value.trim();
        if (!text) {
            showError("Please enter some text to analyze.");
            return;
        }
        
        // Get selected library
        let selectedLibrary = 'nltk';
        libraryOptions.forEach(option => {
            if (option.checked) {
                selectedLibrary = option.value;
            }
        });
        
        // For text similarity, check that comparison text is provided
        if (currentTask === 'text_similarity') {
            const text2 = comparisonText.value.trim();
            if (!text2) {
                showError("Please enter text in both fields for comparison.");
                return;
            }
        }
        
        // Show loading spinner
        resetDisplay();
        loadingSpinner.style.display = 'block';
        
        // Prepare request data
        const requestData = {
            text: text,
            task: currentTask,
            library: selectedLibrary
        };
        
        // Add comparison text if needed
        if (currentTask === 'text_similarity') {
            requestData.comparison_text = comparisonText.value.trim();
        }
        
        // Make API request
        fetch('/process', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            loadingSpinner.style.display = 'none';
            
            if (data.error) {
                showError(data.error);
                return;
            }
            
            displayResult(data.result, currentTask, selectedLibrary);
            
            // Display visualization if available
            if (data.visual_data) {
                displayVisualization(data.visual_data, currentTask);
            } else {
                visualizationContainer.style.display = 'none';
            }
            
            resultContainer.style.display = 'block';
        })
        .catch(error => {
            loadingSpinner.style.display = 'none';
            showError("Error processing request: " + error.message);
        });
    }
    
    function displayResult(result, task, library) {
        const resultBody = resultContainer.querySelector('.card-body');
        let html = '';
        
        switch (task) {
            case 'tokenization':
                html = `
                    <h4>Words</h4>
                    <div class="token-container">
                        ${result.words.map(word => `<span class="token">${word}</span>`).join('')}
                    </div>
                    <h4>Sentences</h4>
                    <ol class="sentence-list">
                        ${result.sentences.map(sentence => `<li>${sentence}</li>`).join('')}
                    </ol>
                `;
                break;
                
            case 'stopword_removal':
                html = `
                    <h4>Filtered Text</h4>
                    <div class="token-container">
                        ${result.filtered_words.map(word => `<span class="token">${word}</span>`).join('')}
                    </div>
                    <h4>Removed Stopwords</h4>
                    <div class="token-container">
                        ${result.removed_words.map(word => `<span class="token removed">${word}</span>`).join('')}
                    </div>
                `;
                break;
                
            case 'lemmatization':
                html = `
                    <h4>Lemmatized Text</h4>
                    <div class="token-container">
                        ${result.lemmatized_words.map(word => `<span class="token">${word}</span>`).join('')}
                    </div>
                    <h4>Lemmatization Details</h4>
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Original Word</th>
                                <th>Lemma</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${Object.entries(result.lemma_dict).map(([word, lemma]) => 
                                `<tr>
                                    <td>${word}</td>
                                    <td>${lemma}</td>
                                </tr>`
                            ).join('')}
                        </tbody>
                    </table>
                `;
                break;
                
            case 'pos_tagging':
                html = `
                    <h4>Part-of-Speech Tags</h4>
                    <div class="pos-container">
                        ${result.pos_tags.map(item => 
                            `<div class="pos-item">
                                <span class="pos-word">${item.word}</span>
                                <span class="pos-tag badge bg-primary">${item.pos}</span>
                                <small>${getPOSDescription(item.pos)}</small>
                            </div>`
                        ).join('')}
                    </div>
                    <h4>POS Distribution</h4>
                    <div class="row mt-3">
                        ${Object.entries(result.pos_groups).map(([pos, count]) => 
                            `<div class="col-md-3 col-sm-4 mb-3">
                                <div class="d-flex justify-content-between">
                                    <span class="badge bg-primary">${pos}</span>
                                    <span class="text-muted">${count}</span>
                                </div>
                                <small>${getPOSDescription(pos)}</small>
                            </div>`
                        ).join('')}
                    </div>
                `;
                break;
                
            case 'ner':
                html = `
                    <h4>Named Entities</h4>
                    <div class="ner-container">
                        ${result.entities.map(entity => 
                            `<div class="ner-item">
                                <span class="ner-text" style="background-color: ${getEntityColor(entity.type)}33; border: 1px solid ${getEntityColor(entity.type)};">
                                    ${entity.text}
                                </span>
                                <span class="ner-type">${entity.type}</span>
                            </div>`
                        ).join('')}
                    </div>
                    <h4>Entity Types Distribution</h4>
                    <div class="row mt-3">
                        ${Object.entries(result.entity_groups).map(([type, count]) => 
                            `<div class="col-md-3 col-sm-4 mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex align-items-center">
                                        <span class="badge" style="background-color: ${getEntityColor(type)};">${type}</span>
                                    </div>
                                    <span class="text-muted">${count}</span>
                                </div>
                            </div>`
                        ).join('')}
                    </div>
                `;
                break;
                
            case 'sentiment_analysis':
                html = `
                    <h4>Sentiment Analysis</h4>
                    <div class="mb-4">
                        <div class="d-flex align-items-center mb-2">
                            <h5 class="mb-0 me-2">Overall Sentiment:</h5>
                            <span class="badge bg-primary ${getSentimentClass(result.sentiment)}">${result.sentiment}</span>
                        </div>
                        <p>The text expresses a predominantly ${result.sentiment.toLowerCase()} sentiment.</p>
                    </div>
                    <h4>Score Breakdown</h4>
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Sentiment</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${Object.entries(result.scores).map(([sentiment, score]) => 
                                `<tr>
                                    <td>${sentiment}</td>
                                    <td>${score.toFixed(4)}</td>
                                </tr>`
                            ).join('')}
                        </tbody>
                    </table>
                `;
                break;
                
            case 'text_summarization':
                html = `
                    <h4>Summary</h4>
                    <div class="card bg-light mb-4">
                        <div class="card-body">
                            <p class="mb-0">${result.summary}</p>
                        </div>
                    </div>
                    <h4>Summary Sentences</h4>
                    <ol class="sentence-list">
                        ${result.summary_sentences.map(sentence => `<li>${sentence}</li>`).join('')}
                    </ol>
                    <div class="mt-3">
                        <span class="badge bg-success">Compression Ratio: ${result.compression_ratio}%</span>
                    </div>
                `;
                break;
                
            case 'keyword_extraction':
                html = `
                    <h4>Keywords</h4>
                    <div class="d-flex flex-wrap gap-2 mb-4">
                        ${result.keywords.map(keyword => 
                            `<span class="badge bg-primary" style="font-size: 0.9rem;">${keyword.word} 
                                <span class="badge bg-light text-dark">${keyword.score.toFixed(3)}</span>
                            </span>`
                        ).join('')}
                    </div>
                `;
                break;
                
            case 'text_similarity':
                html = `
                    <h4>Similarity Analysis</h4>
                    <div class="mb-4">
                        <div class="d-flex align-items-center mb-2">
                            <h5 class="mb-0 me-2">Similarity Score:</h5>
                            <span class="badge bg-primary">${(result.similarity_score * 100).toFixed(2)}%</span>
                        </div>
                        <p>The texts share a ${(result.similarity_score * 100).toFixed(2)}% similarity based on word overlap and semantic analysis.</p>
                    </div>
                    <h4>Common Terms</h4>
                    <div class="token-container mb-4">
                        ${result.common_terms.map(term => `<span class="token">${term}</span>`).join('')}
                    </div>
                `;
                break;
                
            case 'language_detection':
                html = `
                    <h4>Language Detection</h4>
                    <div class="d-flex align-items-center mb-3">
                        <div class="me-3">
                            <span class="fs-1">🌐</span>
                        </div>
                        <div>
                            <h5 class="mb-1">Detected Language: <span class="text-primary">${result.language_name}</span></h5>
                            <p class="mb-0">Language Code: <code>${result.language_code}</code></p>
                            ${result.confidence ? `<p class="mb-0 mt-2">Confidence: <span class="badge bg-primary">${(result.confidence * 100).toFixed(2)}%</span></p>` : ''}
                        </div>
                    </div>
                `;
                break;
                
            default:
                html = `<div class="alert alert-info">No results to display for this task.</div>`;
        }
        
        resultBody.innerHTML = html;
    }
    
    function getPOSDescription(tag) {
        const posDescriptions = {
            'NN': 'Noun, singular',
            'NNS': 'Noun, plural',
            'NNP': 'Proper noun, singular',
            'NNPS': 'Proper noun, plural',
            'VB': 'Verb, base form',
            'VBD': 'Verb, past tense',
            'VBG': 'Verb, gerund/present participle',
            'VBN': 'Verb, past participle',
            'VBP': 'Verb, non-3rd person singular present',
            'VBZ': 'Verb, 3rd person singular present',
            'JJ': 'Adjective',
            'JJR': 'Adjective, comparative',
            'JJS': 'Adjective, superlative',
            'RB': 'Adverb',
            'RBR': 'Adverb, comparative',
            'RBS': 'Adverb, superlative',
            'DT': 'Determiner',
            'IN': 'Preposition or subordinating conjunction',
            'CC': 'Coordinating conjunction',
            'PRP': 'Personal pronoun',
            'PRP$': 'Possessive pronoun',
            'WP': 'Wh-pronoun',
            'WP$': 'Possessive wh-pronoun',
            'WDT': 'Wh-determiner',
            'WRB': 'Wh-adverb',
            'CD': 'Cardinal number',
            'EX': 'Existential there',
            'MD': 'Modal',
            'PDT': 'Predeterminer',
            'POS': 'Possessive ending',
            'RP': 'Particle',
            'SYM': 'Symbol',
            'TO': 'to',
            'UH': 'Interjection',
            'FW': 'Foreign word',
            '.': 'Punctuation',
            ',': 'Comma',
            ':': 'Colon',
            '(': 'Left bracket',
            ')': 'Right bracket',
            'NOUN': 'Noun',
            'VERB': 'Verb',
            'ADJ': 'Adjective',
            'ADV': 'Adverb',
            'ADP': 'Adposition',
            'CONJ': 'Conjunction',
            'DET': 'Determiner',
            'NUM': 'Number',
            'PRON': 'Pronoun',
            'PRT': 'Particle',
            'PUNCT': 'Punctuation',
            'X': 'Other'
        };
        
        return posDescriptions[tag] || tag;
    }
});